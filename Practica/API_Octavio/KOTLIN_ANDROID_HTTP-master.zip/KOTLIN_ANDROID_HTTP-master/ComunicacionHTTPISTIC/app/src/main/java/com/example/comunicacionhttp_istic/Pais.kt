package com.example.comunicacionhttp_istic

import android.media.Image

class Pais(nombre:String, region: String) {
    var nombre=""
    var region=""
    init{
        this.nombre=nombre
        this.region=region
    }
}